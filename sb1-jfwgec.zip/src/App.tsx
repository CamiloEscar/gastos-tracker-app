import React, { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { ExpenseCard } from './components/ExpenseCard';
import { NewExpenseModal } from './components/NewExpenseModal';
import { Sidebar } from './components/Sidebar';
import { ExpenseStats } from './components/ExpenseStats';
import { useExpenseStore } from './store';
import { v4 as uuidv4 } from 'uuid';

function App() {
  const [isNewExpenseModalOpen, setIsNewExpenseModalOpen] = useState(false);
  const { state, addExpense, addParticipantToExpense, addItemToExpense, removeItem, updateItemParticipant } = useExpenseStore();

  useEffect(() => {
    document.documentElement.classList.toggle('dark', state.settings.theme === 'dark');
  }, [state.settings.theme]);

  const filteredExpenses = state.expenses.filter((expense) => {
    const matchesSearch = expense.title
      .toLowerCase()
      .includes(state.searchQuery.toLowerCase());
    const matchesCategory = !state.selectedCategory || expense.category === state.selectedCategory;
    const matchesDateRange =
      (!state.dateRange.start || expense.date >= state.dateRange.start) &&
      (!state.dateRange.end || expense.date <= state.dateRange.end);
    return matchesSearch && matchesCategory && matchesDateRange;
  });

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      <Sidebar />
      
      <main className="flex-1 p-8 overflow-auto">
        <header className="mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">
                Split & Share
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">
                Track and split expenses with friends
              </p>
            </div>
            <button
              onClick={() => setIsNewExpenseModalOpen(true)}
              className="btn-primary inline-flex items-center gap-2"
            >
              <Plus size={20} />
              New Expense
            </button>
          </div>
        </header>

        <ExpenseStats />

        <section className="mt-8 grid gap-6 lg:grid-cols-2 animate-slide-in">
          {filteredExpenses.map((expense) => (
            <ExpenseCard
              key={expense.id}
              expense={expense}
              onAddParticipant={() => {
                const name = prompt('Enter participant name:');
                if (name) {
                  addParticipantToExpense(expense.id, {
                    id: uuidv4(),
                    name,
                  });
                }
              }}
              onAddItem={() => {
                const description = prompt('Enter item description:');
                const amount = parseFloat(prompt('Enter amount:') || '0');
                if (description && !isNaN(amount)) {
                  addItemToExpense(expense.id, {
                    id: uuidv4(),
                    participantId: '',
                    description,
                    amount,
                  });
                }
              }}
              onRemoveItem={(itemId) => removeItem(expense.id, itemId)}
              onUpdateItemParticipant={(itemId, participantId) =>
                updateItemParticipant(expense.id, itemId, participantId)
              }
            />
          ))}
        </section>

        {filteredExpenses.length === 0 && (
          <div className="text-center py-12 animate-slide-in">
            <h3 className="text-lg font-medium mb-2">
              No expenses found
            </h3>
            <p className="text-gray-500 dark:text-gray-400">
              Try adjusting your filters or add a new expense
            </p>
          </div>
        )}
      </main>

      <NewExpenseModal
        isOpen={isNewExpenseModalOpen}
        onClose={() => setIsNewExpenseModalOpen(false)}
        onSubmit={(data) => {
          addExpense({
            id: uuidv4(),
            ...data,
            participants: [],
            items: [],
          });
          setIsNewExpenseModalOpen(false);
        }}
      />
    </div>
  );
}

export default App;