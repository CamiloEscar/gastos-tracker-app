import React from 'react';
import { DollarSign } from 'lucide-react';
import { Expense, Balance } from '../types';

interface Props {
  expense: Expense;
}

export function ExpenseBalances({ expense }: Props) {
  const total = expense.items.reduce((sum, item) => sum + item.amount, 0);
  const perPerson = total / expense.participants.length;

  const balances: Balance[] = expense.participants.map((participant) => {
    const paid = expense.items
      .filter((item) => item.participantId === participant.id)
      .reduce((sum, item) => sum + item.amount, 0);

    return {
      participantId: participant.id,
      paid,
      owes: perPerson - paid,
    };
  });

  return (
    <div className="bg-gray-50 rounded-lg p-4 space-y-3">
      <h4 className="font-medium text-gray-700 flex items-center gap-2">
        <DollarSign size={18} /> Balances
      </h4>
      
      <div className="space-y-2">
        {balances.map((balance) => {
          const participant = expense.participants.find(
            (p) => p.id === balance.participantId
          );
          
          return (
            <div
              key={balance.participantId}
              className="flex justify-between items-center text-sm p-2 bg-white rounded border border-gray-100"
            >
              <span className="font-medium">{participant?.name}</span>
              <div className="flex gap-4">
                <span className="text-gray-600">
                  Paid: ${balance.paid.toFixed(2)}
                </span>
                <span
                  className={
                    balance.owes > 0
                      ? 'text-red-600'
                      : balance.owes < 0
                      ? 'text-green-600'
                      : 'text-gray-600'
                  }
                >
                  {balance.owes > 0
                    ? `Owes: $${balance.owes.toFixed(2)}`
                    : balance.owes < 0
                    ? `Gets back: $${Math.abs(balance.owes).toFixed(2)}`
                    : 'Settled'}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="pt-2 border-t border-gray-200">
        <div className="flex justify-between text-sm font-medium">
          <span>Total Expense</span>
          <span>${total.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-sm text-gray-600">
          <span>Per Person</span>
          <span>${perPerson.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}