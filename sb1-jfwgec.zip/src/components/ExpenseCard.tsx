import React from 'react';
import { PlusCircle, Users } from 'lucide-react';
import { Expense } from '../types';
import { ExpenseItems } from './ExpenseItems';
import { ExpenseBalances } from './ExpenseBalances';
import { ShareExpense } from './ShareExpense';

interface Props {
  expense: Expense;
  onAddParticipant: () => void;
  onAddItem: () => void;
  onRemoveItem: (itemId: string) => void;
  onUpdateItemParticipant: (itemId: string, participantId: string) => void;
}

export function ExpenseCard({
  expense,
  onAddParticipant,
  onAddItem,
  onRemoveItem,
  onUpdateItemParticipant,
}: Props) {
  const categoryIcons = {
    restaurants: '🍽️',
    'food-delivery': '🛵',
    events: '🎉',
    other: '📝',
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 space-y-6 hover:shadow-xl transition-shadow">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <span className="text-2xl">{categoryIcons[expense.category]}</span>
          <div>
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">{expense.title}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">{expense.date}</p>
          </div>
        </div>
        <ShareExpense expense={expense} />
      </div>

      <div className="space-y-6">
        <div>
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-medium text-gray-700 dark:text-gray-300 flex items-center gap-2">
              <Users size={18} /> Participants
            </h4>
            <button
              onClick={onAddParticipant}
              className="text-emerald-600 hover:text-emerald-700"
            >
              <PlusCircle size={20} />
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {expense.participants.map((participant) => (
              <div
                key={participant.id}
                className="text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-700 px-3 py-1 rounded"
              >
                {participant.name}
              </div>
            ))}
          </div>
        </div>

        <ExpenseItems
          expense={expense}
          onAddItem={onAddItem}
          onRemoveItem={onRemoveItem}
          onUpdateItemParticipant={onUpdateItemParticipant}
        />

        {expense.participants.length > 0 && <ExpenseBalances expense={expense} />}
      </div>
    </div>
  );
}