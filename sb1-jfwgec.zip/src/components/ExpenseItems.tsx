import React from 'react';
import { PlusCircle, Receipt, Trash2 } from 'lucide-react';
import { Expense } from '../types';

interface Props {
  expense: Expense;
  onAddItem: () => void;
  onRemoveItem: (itemId: string) => void;
  onUpdateItemParticipant: (itemId: string, participantId: string) => void;
}

export function ExpenseItems({
  expense,
  onAddItem,
  onRemoveItem,
  onUpdateItemParticipant,
}: Props) {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="font-medium text-gray-700 flex items-center gap-2">
          <Receipt size={18} /> Items
        </h4>
        <button
          onClick={onAddItem}
          className="text-emerald-600 hover:text-emerald-700"
        >
          <PlusCircle size={20} />
        </button>
      </div>

      <div className="space-y-2">
        {expense.items.map((item) => (
          <div
            key={item.id}
            className="flex items-center gap-2 text-sm bg-gray-50 px-3 py-2 rounded"
          >
            <select
              value={item.participantId}
              onChange={(e) => onUpdateItemParticipant(item.id, e.target.value)}
              className="text-sm border-0 bg-transparent focus:ring-0"
            >
              <option value="">Assign to...</option>
              {expense.participants.map((participant) => (
                <option key={participant.id} value={participant.id}>
                  {participant.name}
                </option>
              ))}
            </select>
            <span className="flex-1 text-gray-600">{item.description}</span>
            <span className="font-medium">${item.amount.toFixed(2)}</span>
            <button
              onClick={() => onRemoveItem(item.id)}
              className="text-gray-400 hover:text-red-500"
            >
              <Trash2 size={16} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}