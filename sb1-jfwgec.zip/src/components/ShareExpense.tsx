import React from 'react';
import { Share2 } from 'lucide-react';
import { Expense, Balance } from '../types';

interface Props {
  expense: Expense;
}

export function ShareExpense({ expense }: Props) {
  const total = expense.items.reduce((sum, item) => sum + item.amount, 0);
  const perPerson = total / expense.participants.length;

  const balances = expense.participants.map((participant) => {
    const paid = expense.items
      .filter((item) => item.participantId === participant.id)
      .reduce((sum, item) => sum + item.amount, 0);

    return {
      participantId: participant.id,
      name: participant.name,
      paid,
      owes: perPerson - paid,
    };
  });

  const generateMessage = () => {
    const lines = [
      `🧾 Expense: ${expense.title}`,
      `📅 Date: ${expense.date}`,
      `💰 Total: $${total.toFixed(2)}`,
      `👥 Per person: $${perPerson.toFixed(2)}`,
      '\n💳 Balances:',
      ...balances.map((balance) => {
        if (balance.owes > 0) {
          return `${balance.name} owes $${balance.owes.toFixed(2)}`;
        } else if (balance.owes < 0) {
          return `${balance.name} gets back $${Math.abs(balance.owes).toFixed(2)}`;
        }
        return `${balance.name} is settled`;
      }),
      '\n🧮 Items:',
      ...expense.items.map((item) => {
        const participant = expense.participants.find(p => p.id === item.participantId);
        return `${item.description}: $${item.amount.toFixed(2)}${participant ? ` (${participant.name})` : ''}`;
      }),
    ];

    return encodeURIComponent(lines.join('\n'));
  };

  const shareToWhatsApp = () => {
    const message = generateMessage();
    window.open(`https://wa.me/?text=${message}`, '_blank');
  };

  return (
    <button
      onClick={shareToWhatsApp}
      className="inline-flex items-center gap-2 text-sm text-emerald-600 hover:text-emerald-700 font-medium"
    >
      <Share2 size={18} />
      Share via WhatsApp
    </button>
  );
}