import React from 'react';
import {
  BarChart3,
  Calendar,
  Download,
  Upload,
  Moon,
  Sun,
  Search,
} from 'lucide-react';
import { useExpenseStore } from '../store';

export function Sidebar() {
  const { state, setTheme, setDateRange, setSearchQuery, exportData, importData } =
    useExpenseStore();

  const totalExpenses = state.expenses.reduce(
    (sum, expense) =>
      sum + expense.items.reduce((itemSum, item) => itemSum + item.amount, 0),
    0
  );

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const content = e.target?.result as string;
          importData(content);
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  const handleExport = () => {
    const data = exportData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'expenses.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-64 bg-white dark:bg-gray-800 h-screen flex flex-col border-r border-gray-200 dark:border-gray-700">
      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search expenses..."
            className="w-full pl-10 pr-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-emerald-500"
            onChange={(e) => setSearchQuery(e.target.value)}
            value={state.searchQuery}
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">
            Overview
          </h3>
          <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-300">Total Expenses</span>
              <span className="font-medium">${totalExpenses.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">
            Date Range
          </h3>
          <div className="space-y-2">
            <input
              type="date"
              className="w-full px-3 py-2 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-900"
              onChange={(e) =>
                setDateRange({
                  ...state.dateRange,
                  start: e.target.value,
                })
              }
            />
            <input
              type="date"
              className="w-full px-3 py-2 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-900"
              onChange={(e) =>
                setDateRange({
                  ...state.dateRange,
                  end: e.target.value,
                })
              }
            />
          </div>
        </div>

        <div className="space-y-4">
          <button
            onClick={handleExport}
            className="w-full flex items-center gap-2 px-4 py-2 bg-gray-50 dark:bg-gray-900 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            <Download size={18} />
            <span>Export Data</span>
          </button>
          <button
            onClick={handleImport}
            className="w-full flex items-center gap-2 px-4 py-2 bg-gray-50 dark:bg-gray-900 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            <Upload size={18} />
            <span>Import Data</span>
          </button>
        </div>
      </div>

      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <button
          onClick={() =>
            setTheme(state.settings.theme === 'light' ? 'dark' : 'light')
          }
          className="w-full flex items-center gap-2 px-4 py-2 bg-gray-50 dark:bg-gray-900 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          {state.settings.theme === 'light' ? (
            <Moon size={18} />
          ) : (
            <Sun size={18} />
          )}
          <span>{state.settings.theme === 'light' ? 'Dark Mode' : 'Light Mode'}</span>
        </button>
      </div>
    </div>
  );
}